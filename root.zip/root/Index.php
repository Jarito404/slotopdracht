<!DOCTYPE html>
<?php
    $aanmelden = false;

    function login($a) {
        if ($a == true) {
            print "hidden";
        };
    };
    function menu($a) {
            if ($a == true) {
            print "style=visibility:hidden;";
        };
    };
?>

<html>
    <head>
        <title>AJA Leren</title>
        <link rel="stylesheet" href="Opmaak/Style.css">
        <script src="https://kit.fontawesome.com/c298114dd8.js" crossorigin="anonymous"></script>
    </head>
    <body>
        <div class="header">
            <div id="Menu">
                <i <?php menu($aanmelden);?> class="fas fa-bars" id="MenuButton"></i>
            </div>
            <h1>AJA Leren</h1>
        </div>
        <div <?php login($aanmelden);?> id="Inlog">
            <h2> Inloggen </h2>
            <div id="Input">
                <form>
                    <label for="usr">Username:</label><br>
                    <input type="text" id="usr" class="Inlog" name="usr"><br>
                    <label for="pwd">Password:</label><br>
                    <input type="password" id="pwd" class="Inlog" name="pwd"><br><br>
                    <input type="button" value="Inloggen" id="Submit"><br><br>
                    <input type="button" value="Aanmelden" id="Aanmelden">
                </form>
            </div>
        </div>
    </body>
</html>