<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Home</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<link href="style/home/style.css" rel="stylesheet" type="text/css" media="screen" />
	<script src="https://kit.fontawesome.com/c298114dd8.js" crossorigin="anonymous"></script>
</head>
<body>
<script>
	function redirect() {
		window.location.replace("/signup.php");
	}
</script>
    <div class="header">
        <div id="Menu">
            <i class="fas fa-bars" id="MenuButton"></i>
        </div>
        <h1>AJA Leren</h1>
	</div>
	<div id="Inlog">
        <h2> Inloggen </h2>
        <div id="Input">
			<form action="login_proces.php" method="post">
				<label for="usr">E-mail:</label><br>
				<input type="text" class="input" name="mail"><br>
				<label for="pwd">Password:</label><br>
				<input type="password" class="input" name="pwd"><br><br>
				<input id="submit" type="submit" value="Login"/>
				<input id="redirectSignup" type="button" value="Signup" onclick="redirect()"/>
			</form>
		</div>
	</div>	
</body>
</html>