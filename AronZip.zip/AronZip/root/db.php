<?php
function connect() {
  $servername = "localhost";
  $username = "root";
  $password = "usbw";
  $dbname = "gegevens";

  $conn = new mysqli($servername, $username, "usbw", $dbname);
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }
  return $conn;
}
?>