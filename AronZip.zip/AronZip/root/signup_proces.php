<!DOCTYPE html>
<head>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>SS</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
</head>
<body>
<script>
	function redirect() {
		window.location.replace("/index.php");
	}
</script>
<?php 
require 'db.php';
$conn = connect();

$name = stripslashes($_POST['name']);
$email = stripslashes($_POST['email']);
$password = stripslashes($_POST['password']);

$sql = "
INSERT INTO `account` (`id`,`Username`,`Email`,`Password`) 
VALUES (NULL,'$name', '$email', '$password')";

if ($conn->query($sql) === TRUE) {
  echo "<script type=\"text/javascript\">
        window.alert('Signup succes!');
		window.location.replace('/index.php');
      </script>";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}
$conn->close();
?>
</body>
</html>