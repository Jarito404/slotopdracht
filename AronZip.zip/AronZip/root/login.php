<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Login</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<link href="style/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
    <div id="inputCreds">
		<form action="login_proces.php" method="post">
			<label for="eml">Email</label><br>
			<input type="text" id="eml" name="Email"/><br>
			<label for="pwd">Password</label><br>
			<input type="password" id="pwd" name="Password"/><br>
			<input value="Login" type="submit"/>
		</form>
	</div>
</body>
</html>