<!DOCTYPE html>
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<title>Signup</title>
	<meta name="keywords" content="" />
	<meta name="description" content="" />
	<link href="style/style.css" rel="stylesheet" type="text/css" media="screen" />
</head>
<body>
<script>
	function redirect() {
		window.location.replace("/index.php");
	}
</script>
<form action="signup_proces.php" method="post">
Naam: <input type="text" name="name"><br>
E-mail: <input type="text" name="email"><br>
Assword: <input type="text" name="password"><br>
<input type="submit">
</form>
<br><input id="homeRedirect" type="button" value="Back" onclick="redirect()"/>

<?php
$servername = "localhost";
$username = "root";
$password = "usbw";
$dbname = "gegevens";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}	
$sql = "SELECT `id`, `Username`, `Email`, `Password` FROM `account` ";
$result = $conn->query($sql);

$conn->close();
?>
</body>
</html>
		