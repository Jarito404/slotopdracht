<!DOCTYPE html>
<html>
<head>
</head>
<body>
<?php
$email = $_POST["mail"];
$password = $_POST["pwd"];

require 'db.php';
$conn = connect();

$sql = "SELECT * 
FROM `account`, 
(SELECT @email := '$email', @password := '$password') AS var 
WHERE Email=@email 
AND Password=@password";

$result = $conn->query($sql);
if ($result->num_rows > 0) {
  while($row = $result->fetch_assoc() ) {
    echo "
      <script type=\"text/javascript\">
        window.alert('Welcome back!');
		window.location.replace('/online/studentEnvironment.php');
      </script>
    ";
  }
} else {
  echo "
    <script type=\"text/javascript\">
      window.alert('Invalid email or password!');
      window.location.replace('/index.php');
    </script>
  ";
}
$conn->close();
?>
</body>
</html>